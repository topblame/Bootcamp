package kr.co.soldesk.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.co.soldesk.beans.ContentBean;
import kr.co.soldesk.service.BoardService;

@Controller
@RequestMapping("/board")
public class BoardController {
	
	@Autowired
	private BoardService boardService;

	@GetMapping("/main")
	public String main(@RequestParam("board_info_idx") int board_info_idx, Model model) {
		// String board_info_idx = request.getParameter("board_info_idx");
		model.addAttribute("board_info_idx", board_info_idx);
		
		//메서드 호출 이름받기.
		String boardInfoName= boardService.getBoardInfoName(board_info_idx);
		//model에 저장후 
		model.addAttribute("boardInfoName", boardInfoName);
		
		//메서드 호출후 게시글 리스트 받기
		List<ContentBean> contentList = boardService.getContentList(board_info_idx);
		model.addAttribute("contentList", contentList);

		return "board/main"; //forward.
	}
	
	@GetMapping("/read")
	public String read(@RequestParam("board_info_idx") int board_info_idx,
			@RequestParam("content_idx") int content_idx, Model model) {
		//글 목록보기시 필요.
		model.addAttribute("board_info_idx", board_info_idx);
		ContentBean readContentBean = boardService.getContentInfo(content_idx);
		model.addAttribute("readContentBean", readContentBean);
		return "board/read";
	}
	@GetMapping("/write")
	public String write(@ModelAttribute("writeContentBean") ContentBean writeContentBean,
			@RequestParam("board_info_idx") int board_info_idx) {
		writeContentBean.setContent_board_idx(board_info_idx);
		return "board/write";
	}
	@PostMapping("/write_pro")
	public String write_pro(@Valid @ModelAttribute("writeContentBean") ContentBean writeContentBean, BindingResult result) {
		if(result.hasErrors()) {
			return "board/write";
		}
		//제목, 내용, 이미지, 게시판종류(부서)
		boardService.addContentInfo(writeContentBean);
		return "board/write_success";
	}
	@GetMapping("/delete")
	public String delete() {
		return "board/delete";
	}
	@GetMapping("/modify")
	public String modify() {
		return "board/modify";
	}
}
